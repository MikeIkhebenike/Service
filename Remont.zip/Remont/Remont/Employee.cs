﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Remont.EF;

namespace Remont
{
    public partial class Employee : Form
    {
        Model1 db = new Model1();
        public Employee()
        {
            InitializeComponent();
        }

        private void Employee_Load(object sender, EventArgs e)
        {
            sotrydnikBindingSource.DataSource = db.Сотрудник.ToList();
            authorizeBindingSource.DataSource = db.Авторизация.ToList();
            roleBindingSource.DataSource = db.Роль.ToList();
        }
    }
}

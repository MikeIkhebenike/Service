﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Remont.EF;

namespace Remont
{
    public partial class Authorize : Form
    {

        public static Авторизация UFN {get;set;}
        public static Authorize ATH {get;set;}
        Model1 db = new Model1();

        public Authorize()
        {
            InitializeComponent();
        }

        private void Authorize_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            if (LoginTxt.Text == "" || PassTxt.Text == "")
            {
                MessageBox.Show("Введите логин и пароль!");
                return;
            }
            Авторизация UsersFind = db.Авторизация.Find(LoginTxt.Text);
            if ((UsersFind != null) && (UsersFind.Пароль == PassTxt.Text))
            {
                UFN = UsersFind;
                ATH = this;
                if (UFN.Сотрудник.ID_роли == 1)
                {
                    Admin FRMadm = new Admin();
                    FRMadm.Show();
                    this.Hide();
                }
                else // если такой роли нет
                {
                    // если данные введены неправильно, то показываем сообщение
                    MessageBox.Show($"Роли в системе нет!");
                    return;
                }


            }
            else
            {
                MessageBox.Show("Логин или пароль введены неверно!");
                return;
            }
        }
    }
}
